<?php
include 'ip.php';
header('Location: https://www.youtube.com/watch?v=_OkXBd8dcN4&t=5449s');
exit();
?>